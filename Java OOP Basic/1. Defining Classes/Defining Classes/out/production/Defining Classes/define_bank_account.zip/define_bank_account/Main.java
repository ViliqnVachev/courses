package define_bank_account;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        Map<Integer, BankAccount> accounts = new HashMap<>();

        String line = reader.readLine();

        while (!"End".equals(line)) {
            String command = line.split(" ")[0];
            int id = Integer.parseInt(line.split(" ")[1]);

            switch (command) {
                case "Create":
                    if (!accounts.containsKey(id)) {
                        BankAccount ba = new BankAccount();
                        ba.setId(id);
                        accounts.put(id, ba);
                    } else {
                        System.out.println("Account already exists");
                    }
                    break;
                case "Deposit":
                    if (!accounts.containsKey(id)) {
                        System.out.println("Account does not exist");
                    } else {
                        BankAccount acc = accounts.get(id);
                        double amount = Double.parseDouble(line.split(" ")[2]);
                        acc.deposit(amount);
                    }
                    break;
                case "Withdraw":
                    if (!accounts.containsKey(id)) {
                        System.out.println("Account does not exist");
                    } else {
                        BankAccount acc = accounts.get(id);
                        double amount = Double.parseDouble(line.split(" ")[2]);
                        acc.withdraw(amount);
                    }

                    break;
                case "Print":
                    if (!accounts.containsKey(id)) {
                        System.out.println("Account does not exist");
                    } else {
                        System.out.println(accounts.get(id));
                    }
                    break;
            }

            line = reader.readLine();
        }
    }
}
