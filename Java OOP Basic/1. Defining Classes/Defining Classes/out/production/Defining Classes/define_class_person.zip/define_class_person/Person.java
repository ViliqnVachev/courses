package define_class_person;

public class Person {
    private String name;
    private int age;
}
