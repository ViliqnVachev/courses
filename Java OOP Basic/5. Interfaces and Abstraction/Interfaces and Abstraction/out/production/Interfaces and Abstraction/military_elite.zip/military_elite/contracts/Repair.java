package military_elite.contracts;

public interface Repair {
}
