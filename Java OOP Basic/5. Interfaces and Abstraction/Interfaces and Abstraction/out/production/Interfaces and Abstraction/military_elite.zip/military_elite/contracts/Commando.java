package military_elite.contracts;

public interface Commando extends SpecialisedSoldier {
}
