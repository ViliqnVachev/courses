package military_elite.contracts;

public interface Private extends Soldier {
}
