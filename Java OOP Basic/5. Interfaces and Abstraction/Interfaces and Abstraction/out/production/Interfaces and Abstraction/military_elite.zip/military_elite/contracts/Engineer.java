package military_elite.contracts;

public interface Engineer extends SpecialisedSoldier {
}
