package military_elite.contracts;

public interface SpecialisedSoldier extends Private {
}
