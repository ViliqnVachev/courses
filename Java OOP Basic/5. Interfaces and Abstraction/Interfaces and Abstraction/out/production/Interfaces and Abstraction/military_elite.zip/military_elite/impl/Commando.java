package military_elite.impl;

import military_elite.contracts.Mission;

import java.util.Set;

public class Commando extends SpecialisedSoldier implements military_elite.contracts.Commando {
    private Set<Mission> missions;

    public Commando(String id, String firstName, String lastName, double salary, String corps, Set<Mission> missions) {
        super(id, firstName, lastName, salary, corps);
        this.missions = missions;
    }

    @Override
    public String toString() {
        StringBuilder commando = new StringBuilder(super.toString()).append(System.lineSeparator());
        commando.append("Missions:");

        for (Mission mission : this.missions) {
            commando.append(System.lineSeparator()).append("  ").append(mission);
        }
        return commando.toString();
    }
}
