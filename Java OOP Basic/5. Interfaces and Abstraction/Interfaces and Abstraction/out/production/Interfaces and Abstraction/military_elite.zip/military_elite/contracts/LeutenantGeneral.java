package military_elite.contracts;

public interface LeutenantGeneral extends Private {
}
