package military_elite.impl;

public class Private extends BaseSoldier implements military_elite.contracts.Private {
    private double salary;

    public Private(String id, String firstName, String lastName, double salary) {
        super(id, firstName, lastName);
        this.salary = salary;
    }

    @Override
    public String toString() {
        StringBuilder privates = new StringBuilder(super.toString()).append(String.format(" Salary: %.2f", this.salary));
        return privates.toString();
    }
}
