package military_elite.impl;


import java.util.LinkedHashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class LeutenantGeneral extends Private implements military_elite.contracts.LeutenantGeneral {
    private Set<military_elite.contracts.Private> privates;

    public LeutenantGeneral(String id, String firstName, String lastName, double salary, Set<military_elite.contracts.Private> privates) {
        super(id, firstName, lastName, salary);
        this.privates = privates;
    }

    @Override
    public String toString() {
        StringBuilder lGeneral = new StringBuilder(super.toString()).append(System.lineSeparator());
        lGeneral.append("Privates:");

        Set<military_elite.contracts.Private> sortedPrivates = this.privates
                .stream()
                .sorted((p1, p2) -> p2.getId().compareTo(p1.getId()))
                .collect(Collectors.toCollection(LinkedHashSet::new));


        for (military_elite.contracts.Private privateSoldier : sortedPrivates) {

            lGeneral.append(System.lineSeparator()).append("  ").append(privateSoldier);

        }

        return lGeneral.toString();
    }
}
