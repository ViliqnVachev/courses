package military_elite.impl;

public abstract class SpecialisedSoldier extends Private implements military_elite.contracts.SpecialisedSoldier {
    private static final String AIR_FORCES_CORPS_TYPE = "Airforces";
    private static final String MARINES_CORPS_TYPE = "Marines";

    private String corps;

    protected SpecialisedSoldier(String id, String firstName, String lastName, double salary, String corps) {
        super(id, firstName, lastName, salary);
        this.setCorps(corps);
    }

    private void setCorps(String corps) {
        if (!AIR_FORCES_CORPS_TYPE.equals(corps) && !MARINES_CORPS_TYPE.equals(corps)) {
            throw new IllegalArgumentException();
        }
        this.corps = corps;
    }

    @Override
    public String toString() {
        StringBuilder specSoldier = new StringBuilder(super.toString()).append(System.lineSeparator());
        specSoldier.append(String.format("Corps: %s", this.corps));

        return specSoldier.toString();
    }
}
