package wild_farm;

public class Vegetable extends Food {
    public Vegetable(int quantity) {
        super(quantity);
    }
}
