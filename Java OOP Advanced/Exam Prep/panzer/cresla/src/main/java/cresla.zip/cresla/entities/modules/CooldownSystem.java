package cresla.entities.modules;

import cresla.interfaces.AbsorbingModule;

public class CooldownSystem extends BaseAbsorbingModule {

    public CooldownSystem(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
