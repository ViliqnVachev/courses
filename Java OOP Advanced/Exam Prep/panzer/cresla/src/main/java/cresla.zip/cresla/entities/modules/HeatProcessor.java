package cresla.entities.modules;

import cresla.interfaces.AbsorbingModule;

public class HeatProcessor extends BaseAbsorbingModule {

    public HeatProcessor(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
