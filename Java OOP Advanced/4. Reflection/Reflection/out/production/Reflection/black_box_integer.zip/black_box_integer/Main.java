package black_box_integer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Main {
    public static void main(String[] args) throws NoSuchMethodException,
            IllegalAccessException, InvocationTargetException,
            InstantiationException, IOException, NoSuchFieldException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Class aClass = BlackBoxInt.class;

        Constructor boxConstructor = aClass.getDeclaredConstructor();
        boxConstructor.setAccessible(true);
        BlackBoxInt blackBox = (BlackBoxInt) boxConstructor.newInstance();
        boxConstructor.setAccessible(false);


        String line = reader.readLine();
        while (!"END".equals(line)) {
            String[] tokens = line.split("_");

            String command = tokens[0];
            int parameter = Integer.parseInt(tokens[1]);



            switch (command) {

                case "add":
                    Method add = blackBox.getClass().getDeclaredMethod("add", int.class);
                    add.setAccessible(true);
                    add.invoke(blackBox, parameter);
                    add.setAccessible(false);

                    break;

                case "subtract":
                    Method subtract = blackBox.getClass().getDeclaredMethod("subtract", int.class);
                    subtract.setAccessible(true);
                    subtract.invoke(blackBox, parameter);
                    subtract.setAccessible(false);
                    break;

                case "divide":
                    Method divide = blackBox.getClass().getDeclaredMethod("divide", int.class);
                    divide.setAccessible(true);
                    divide.invoke(blackBox, parameter);
                    divide.setAccessible(false);
                    break;

                case "multiply":
                    Method multiply = blackBox.getClass().getDeclaredMethod("multiply", int.class);
                    multiply.setAccessible(true);
                    multiply.invoke(blackBox, parameter);
                    multiply.setAccessible(false);
                    break;

                case "rightShift":
                    Method rightShift = blackBox.getClass().getDeclaredMethod("rightShift", int.class);
                    rightShift.setAccessible(true);
                    rightShift.invoke(blackBox, parameter);
                    rightShift.setAccessible(false);
                    break;

                case "leftShift":
                    Method leftShift = blackBox.getClass().getDeclaredMethod("leftShift", int.class);
                    leftShift.setAccessible(true);
                    leftShift.invoke(blackBox, parameter);
                    leftShift.setAccessible(false);
                    break;
            }

            Field innerValue = blackBox.getClass().getDeclaredField("innerValue");
            innerValue.setAccessible(true);
            System.out.println(innerValue.get(blackBox));

            line = reader.readLine();
        }
        System.out.println();
    }
}
