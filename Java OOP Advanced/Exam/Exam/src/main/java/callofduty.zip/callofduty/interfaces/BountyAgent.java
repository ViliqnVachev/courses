package callofduty.interfaces;

public interface BountyAgent extends Agent, Bountyable {
}
