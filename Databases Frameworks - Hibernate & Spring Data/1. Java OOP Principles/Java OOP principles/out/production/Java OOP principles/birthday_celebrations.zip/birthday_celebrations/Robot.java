package birthday_celebrations;

public class Robot extends Population {
    protected Robot(String name, String id) {
        super(name, id);
    }

}
