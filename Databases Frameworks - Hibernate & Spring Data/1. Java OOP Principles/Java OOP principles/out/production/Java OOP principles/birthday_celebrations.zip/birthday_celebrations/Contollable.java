package birthday_celebrations;

public interface Contollable {
    boolean getFakeId(String lastDigit);
}
