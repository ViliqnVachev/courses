package birthday_celebrations;

public interface Birthtable {
    String getBirthdate();
}
