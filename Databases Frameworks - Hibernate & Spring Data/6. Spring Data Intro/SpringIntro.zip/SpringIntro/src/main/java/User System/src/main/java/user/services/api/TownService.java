package user.services.api;

public interface TownService {
}
