package user.services.api;

public interface PictureService {
}
