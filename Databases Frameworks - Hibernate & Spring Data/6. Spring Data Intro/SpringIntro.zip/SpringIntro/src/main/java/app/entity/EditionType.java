package app.entity;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
