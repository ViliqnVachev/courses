package app.service;

import java.io.IOException;

public interface CategoryService {
    void seedCategory() throws IOException;
}
