package app.entity;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
