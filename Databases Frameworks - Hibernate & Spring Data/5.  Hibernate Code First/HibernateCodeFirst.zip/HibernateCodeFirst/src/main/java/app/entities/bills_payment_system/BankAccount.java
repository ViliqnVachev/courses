//package app.entities.bills_payment_system;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//
//@Entity(name = "bank_accounts")
//public class BankAccount extends BillingDetail {
//    private String bankName;
//    private String SWIFT;
//
//    @Column(name = "bank_name")
//    public String getBankName() {
//        return bankName;
//    }
//
//    public void setBankName(String bankName) {
//        this.bankName = bankName;
//    }
//
//    @Column(name = "code")
//    public String getSWIFT() {
//        return SWIFT;
//    }
//
//    public void setSWIFT(String SWIFT) {
//        this.SWIFT = SWIFT;
//    }
//}
