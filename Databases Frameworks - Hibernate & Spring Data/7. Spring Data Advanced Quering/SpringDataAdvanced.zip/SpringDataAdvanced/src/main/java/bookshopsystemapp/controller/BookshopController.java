package bookshopsystemapp.controller;

import bookshopsystemapp.domain.entities.AgeRestriction;
import bookshopsystemapp.service.AuthorService;
import bookshopsystemapp.service.BookService;
import bookshopsystemapp.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Set;

@Controller
public class BookshopController implements CommandLineRunner {
    private static final DateTimeFormatter DATE_FORMAT_MONTH_SHORT_NAME = DateTimeFormatter.ofPattern("dd MMM yyyy");

    private final AuthorService authorService;
    private final CategoryService categoryService;
    private final BookService bookService;

    @Autowired
    public BookshopController(AuthorService authorService, CategoryService categoryService, BookService bookService) {
        this.authorService = authorService;
        this.categoryService = categoryService;
        this.bookService = bookService;
    }

    @Override
    public void run(String... strings) throws Exception {
// this.authorService.seedAuthors();
// this.categoryService.seedCategories();
// this.bookService.seedBooks();

        //Problem 1 Books Titles By Age Restriction this.booksTitlesByAgeRestriction();
        //Problem 2 Golden Books this.goldenBooks();
        //Problem 3 Books by Price this.booksByPrice();
        //Problem 4 Not Released Books this.notReleasedBook();
        //Problem 5 Books Released Before Date this.booksReleasedBeforeDate();
        //Problem 6 Authors Search this.authorsSearch();
        //Problem 7 Books Search this.getTitlesByString();
        //Problem 8 Book Titles Search this.booksTitlesSearch();
        //Problem 9 Count Books this.countBooks();
        //Problem 10 Total Book Copies this.totalBookCopies();
        this.increaseBookCopies();

    }

    //Problem 12 Increase Book Copies
    private void increaseBookCopies() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Enter start release date to increase book copies (dd MMM yyyy): ");
        LocalDate startDate = LocalDate.parse(reader.readLine().trim(), DATE_FORMAT_MONTH_SHORT_NAME);

        System.out.print("Enter copies to add to each title: ");

        int copiesToAdd = Integer.parseInt(reader.readLine());

        Integer modifiedBooks = this.bookService.increaseCopiesForBooksReleasedAfterDate(startDate, copiesToAdd);

        System.out.println(modifiedBooks * copiesToAdd);
    }

    //Problem 10 Total Book Copies
    private void totalBookCopies() {
        this.authorService.getAuthorsByBookCopiesCount().forEach(o -> System.out.println(o));
    }

    //Problem 9 Count Books
    private void countBooks() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Integer param = Integer.parseInt(reader.readLine());

        System.out.println(this.bookService.getCountOfBooksWithTitleLongerThan(param));
    }

    //Problem 8 Book Titles Search
    private void booksTitlesSearch() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String data = reader.readLine();

        this.bookService.booksByAuthor(data).forEach(System.out::println);
    }

    //Problem 7 Books Search
    private void getTitlesByString() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String data = reader.readLine();

        this.bookService.booksSearch(data).forEach(System.out::println);
    }

    //Problem 6 Authors Search
    private void authorsSearch() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String ends = reader.readLine();
        this.authorService.getAuthorNameEndsWith(ends).forEach(System.out::println);
    }

    //Problem 5 Books Released Before Date
    private void booksReleasedBeforeDate() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String date = reader.readLine();
        this.bookService.getAllBooksTitleBefore(date).forEach(System.out::println);
    }

    // Problem 4 Not Released Books
    private void notReleasedBook() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String year = reader.readLine();
        this.bookService.getNotReleaseInYear(year).forEach(System.out::println);
    }

    //Problem 3 Books by Price
    private void booksByPrice() {
        this.bookService.getBooksByPrice().forEach(System.out::println);
    }

    //Problem 2 Golden Books
    private void goldenBooks() {
        this.bookService.getAllGoldenBooksTitles().forEach(System.out::println);
    }

    //Problem 1 Books Titles By Age Restriction
    private void booksTitlesByAgeRestriction() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String ageRestrictionString = reader.readLine();
        this.bookService.getAllBookByAgeRestrictions(ageRestrictionString).forEach(System.out::println);

    }
}
