package bookshopsystemapp.service;

import bookshopsystemapp.domain.entities.AgeRestriction;
import bookshopsystemapp.domain.entities.EditionType;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;

public interface BookService {

    void seedBooks() throws IOException;

    List<String> getAllBooksTitlesAfter();

    List<String> getAllBooksTitleBefore(String date);

    List<String> getAllBookByAgeRestrictions(String ageRestriction);

    List<String> getAllGoldenBooksTitles();

    List<String> getBooksByPrice();

    List<String> getNotReleaseInYear(String year);

    List<String> booksSearch(String data);

    List<String> booksByAuthor(String data);

    Integer getCountOfBooksWithTitleLongerThan(Integer length);

    Integer increaseCopiesForBooksReleasedAfterDate(LocalDate startDate, Integer copiesToAdd);

}
