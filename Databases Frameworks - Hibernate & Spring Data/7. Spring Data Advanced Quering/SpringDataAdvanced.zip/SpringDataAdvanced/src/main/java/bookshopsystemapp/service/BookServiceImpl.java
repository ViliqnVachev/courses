package bookshopsystemapp.service;

import bookshopsystemapp.domain.entities.*;
import bookshopsystemapp.repository.AuthorRepository;
import bookshopsystemapp.repository.BookRepository;
import bookshopsystemapp.repository.CategoryRepository;
import bookshopsystemapp.util.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
public class BookServiceImpl implements BookService {

    private final static String BOOKS_FILE_PATH = "C:\\Users\\Viliyan\\Desktop\\soft uni\\Databases Frameworks - Hibernate & Spring Data\\7. Spring Data Advanced Quering\\SpringDataAdvanced\\src\\main\\resources\\files\\books.txt";

    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;
    private final CategoryRepository categoryRepository;
    private final FileUtil fileUtil;

    @Autowired
    public BookServiceImpl(BookRepository bookRepository, AuthorRepository authorRepository, CategoryRepository categoryRepository, FileUtil fileUtil) {
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
        this.categoryRepository = categoryRepository;
        this.fileUtil = fileUtil;
    }

    @Override
    public void seedBooks() throws IOException {
        if (this.bookRepository.count() != 0) {
            return;
        }

        String[] booksFileContent = this.fileUtil.getFileContent(BOOKS_FILE_PATH);
        for (String line : booksFileContent) {
            String[] lineParams = line.split("\\s+");

            Book book = new Book();
            book.setAuthor(this.getRandomAuthor());

            EditionType editionType = EditionType.values()[Integer.parseInt(lineParams[0])];
            book.setEditionType(editionType);

            LocalDate releaseDate = LocalDate.parse(lineParams[1], DateTimeFormatter.ofPattern("d/M/yyyy"));
            book.setReleaseDate(releaseDate);

            int copies = Integer.parseInt(lineParams[2]);
            book.setCopies(copies);

            BigDecimal price = new BigDecimal(lineParams[3]);
            book.setPrice(price);

            AgeRestriction ageRestriction = AgeRestriction.values()[Integer.parseInt(lineParams[4])];
            book.setAgeRestriction(ageRestriction);

            StringBuilder title = new StringBuilder();
            for (int i = 5; i < lineParams.length; i++) {
                title.append(lineParams[i]).append(" ");
            }

            book.setTitle(title.toString().trim());

            Set<Category> categories = this.getRandomCategories();
            book.setCategories(categories);

            this.bookRepository.saveAndFlush(book);
        }
    }

    @Override
    public List<String> getAllBooksTitlesAfter() {
        List<Book> books = this.bookRepository.findAllByReleaseDateAfter(LocalDate.parse("2000-12-31"));

        return books.stream().map(Book::getTitle).collect(Collectors.toList());
    }

    @Override
    public Integer getCountOfBooksWithTitleLongerThan(Integer length) {
        return this.bookRepository.getCountOfBooksWithTitleLongerThan(length);
    }

    @Override
    public List<String> booksByAuthor(String data) {
        List<Author> authors = this.authorRepository.findAllByLastNameStartingWith(data)
                .stream().sorted((a1, a2) -> a1.getFirstName().compareTo(a2.getLastName()))
                .collect(Collectors.toList());

        List<String> booksTitles = new ArrayList<>();

        for (Author author : authors) {
            this.bookRepository.findAllByAuthor(author).forEach(a -> {
                String title = String.format("%s (%s %s)", a.getTitle(), a.getAuthor().getFirstName(), a.getAuthor().getLastName());
                booksTitles.add(title);
            });
        }

        return booksTitles;
    }

    @Override
    public Integer increaseCopiesForBooksReleasedAfterDate(LocalDate startDate, Integer copiesToAdd) {
        return this.bookRepository.increaseCopiesForBooksReleasedAfterDate(startDate, copiesToAdd);
    }

    @Override
    public List<String> booksSearch(String data) {
        return this.bookRepository.findAllByTitleContaining(data).stream()
                .map(Book::getTitle).collect(Collectors.toList());
    }

    @Override
    public List<String> getAllBooksTitleBefore(String date) {
        String[] dataInput = date.split("-");
        List<Book> books = this.bookRepository.findAllByReleaseDateBefore(LocalDate.parse(dataInput[2] + "-" + dataInput[1] + "-" + dataInput[0]));

        return books.stream().map(b -> String.format("%s", b.getTitle())).collect(Collectors.toList());
    }

    @Override
    public List<String> getAllBookByAgeRestrictions(String ageRestrictionStr) {
        AgeRestriction ageRestriction = AgeRestriction.valueOf(ageRestrictionStr.toUpperCase());
        return this.bookRepository.findAllByAgeRestriction(ageRestriction).stream().map(Book::getTitle).collect(Collectors.toList());
    }

    @Override
    public List<String> getAllGoldenBooksTitles() {
        Integer copies = 5000;
        EditionType editionType = EditionType.GOLD;
        return this.bookRepository.findAllByEditionTypeIsAndCopiesLessThan(editionType, copies)
                .stream().map(Book::getTitle).collect(Collectors.toList());
    }

    @Override
    public List<String> getBooksByPrice() {
        BigDecimal lowerPrice = new BigDecimal(5);
        BigDecimal greaterPrice = new BigDecimal(40);

        List<String> booksByPrice = new ArrayList<>();

        this.bookRepository.findAllByPriceIsLessThanOrPriceGreaterThan(lowerPrice, greaterPrice)
                .forEach(b -> {
                            StringBuilder sb = new StringBuilder();
                            sb.append(String.format("%s - $%.2f ", b.getTitle(), b.getPrice()));
                            booksByPrice.add(sb.toString());
                        }
                );

        return booksByPrice;
    }

    @Override
    public List<String> getNotReleaseInYear(String year) {
        LocalDate before = LocalDate.parse(year + "-01" + "-01");
        LocalDate after = LocalDate.parse(year + "-12" + "-31");
        return this.bookRepository.findAllByReleaseDateBeforeOrReleaseDateAfter(before, after)
                .stream().map(Book::getTitle).collect(Collectors.toList());

    }

    private Author getRandomAuthor() {
        Random random = new Random();

        int randomId = random.nextInt((int) (this.authorRepository.count() - 1)) + 1;

        return this.authorRepository.findById(randomId).orElse(null);
    }

    private Set<Category> getRandomCategories() {
        Set<Category> categories = new LinkedHashSet<>();

        Random random = new Random();
        int length = random.nextInt(5);

        for (int i = 0; i < length; i++) {
            Category category = this.getRandomCategory();

            categories.add(category);
        }

        return categories;
    }

    private Category getRandomCategory() {
        Random random = new Random();

        int randomId = random.nextInt((int) (this.categoryRepository.count() - 1)) + 1;

        return this.categoryRepository.findById(randomId).orElse(null);
    }
}
